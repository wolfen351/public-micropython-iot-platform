#!/bin/bash

picocom /dev/ttyACM0 -b 115200 -q
