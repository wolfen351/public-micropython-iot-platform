Settings = { 
    'Name': 'Master Template',
    'ShortName': 'Master',
}
