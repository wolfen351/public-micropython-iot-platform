Settings = { 
    'Name': 'Temperature Sensor DHT22',
    'ShortName': 'DHT22',
}
