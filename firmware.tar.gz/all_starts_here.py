Settings = { 
    'Name': 'Temperature Sensor',
    'ShortName': 'TempMon',
}
