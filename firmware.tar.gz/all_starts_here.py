Settings = { 
    'Name': 'Temperature Sensor DHT11',
    'ShortName': 'DHT11',
}