Settings = { 
    'Name': 'Four Lights',
    'ShortName': 'FourLights',
}
