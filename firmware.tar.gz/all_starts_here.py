Settings = { 
    'Name': 'Led Strip Controller',
    'ShortName': 'LedStrip',
}