#!/bin/bash

picocom /dev/ttyUSB0 -b 115200