Settings = { 
    'Name': 'Mosfet Controller',
    'ShortName': 'Mosfet',
}
