from xglcd_font import XglcdFont

font = XglcdFont('modules/touchscreen/font25x57.c', 25, 57, 32, 97, 228)