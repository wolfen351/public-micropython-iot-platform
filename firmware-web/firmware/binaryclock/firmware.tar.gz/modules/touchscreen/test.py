from xglcd_font import XglcdFont

font = XglcdFont('modules/touchscreen/fonts/font25x57.c', 25, 57, 32, 97, 228)