Settings = { 
    'Name': 'Binary Clock',
    'ShortName': 'BinaryClock',
}
