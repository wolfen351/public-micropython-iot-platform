Green is IO2, used when communicating over UART. Blue is battery charging (it seems to me always on when USB and battery is connected), red is always on when power on. 

