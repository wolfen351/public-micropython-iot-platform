Settings = { 
    'Name': 'GPS',
    'ShortName': 'GPS',
}
